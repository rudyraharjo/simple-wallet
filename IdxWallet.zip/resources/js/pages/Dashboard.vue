<template>
    <v-layout>
        <v-row>
            <v-col cols="12" sm="12" md="12">
                <h1 class="display-1 mb-1">Dashboard</h1>
            </v-col>
            <!--
            <v-col cols="12" sm="6" md="3" lg="3"> 
                <v-card color="green darken-1" style="height: 100%;" dark>
                    <v-card-text class="text-center" style="color:#fff">
                        <div class="display-1 mb-2">2000000</div>
                        <p class="font-weight-medium">Saldo</p>
                    </v-card-text>
                </v-card>
            </v-col>
            
            <v-col cols="12" sm="6" md="3" lg="3"> 
                <v-card color="orange darken-3" style="height: 100%;" dark>
                    <v-card-text class="text-center" style="color:#fff">
                        <div class="display-1 mb-2">{{ countTransactionPending }}</div>
                        <p class="font-weight-medium">Trasnsactions Pending</p>
                    </v-card-text>
                </v-card>
            </v-col>
            <v-col cols="12" sm="6" md="3" lg="3"> 
                <v-card color="lime darken-1" style="height: 100%;" dark>
                    <v-card-text class="text-center" style="color:#fff">
                        <div class="display-1 mb-2">{{ countTransactionProcess }}</div>
                        <p class="font-weight-medium">Trasnsactions On Process</p>
                    </v-card-text>
                </v-card>
            </v-col>
            <v-col cols="12" sm="6" md="3" lg="3"> 
                <v-card color="light-blue accent-4" style="height: 100%;" dark>
                    <v-card-text class="text-center" style="color:#fff">
                        <div class="display-1 mb-2">{{ countTransactionDone }}</div>
                        <p class="font-weight-medium">Trasnsactions Done</p>
                    </v-card-text>
                </v-card>
            </v-col>
            -->
        </v-row>  
        
    </v-layout>
</template>

<script>
    export default {
        created() {
            
        },
        methods: {
        },
        computed:{ 
            
        }
    }
</script>